RongGhor Android source project — version 1.0 demo
ফিচার: পণ্য ক্যাটালগ, সার্চ/ক্যাটাগরি, কার্ট/পরিমাণ, গ্রাহকের তথ্য, WhatsApp অর্ডার।
WhatsApp অর্ডার নম্বর: 01737676080 (international format 8801737676080)
সতর্কতা: পণ্যের মূল্য/স্টক ডেমো; APK এখনো বিল্ড করা হয়নি।
APK build: Android Studio ইনস্টল করুন > Open এই RongGhorAndroid ফোল্ডার > Gradle Sync > Build > Build Bundle(s) / APK(s) > Build APK(s)।
সাধারণত APK পাবেন app/build/outputs/apk/debug/app-debug.apk ফাইলে।
